<?php
  // Start the session
  session_start();
  ?>
  <?php
  $dsn = 'mysql:host=localhost;dbname=exchange';
  $username ="root";
  $password ="";
  $database ="exchange";
  try{
    $dbh = new PDO($dsn, $username, $password);
  }
  catch(PDOException $e){
    echo 'ERROR: ' .$e->getMessage();
  }
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $selectDept = "SELECT DISTINCT Department FROM exchange_table ORDER BY Department ASC";
  $selectDeptQuery  = $dbh->prepare($selectDept);
  $selectDeptStatus = $selectDeptQuery->execute();
  if($selectDeptStatus)
    {
    $rowDept = $selectDeptQuery->fetchAll();
      
    }else{
      echo "failed";
    }
  $selectOffice = "SELECT DISTINCT Office FROM exchange_table ORDER BY Office ASC";
  $selectOfficeQuery  = $dbh->prepare($selectOffice);
  $selectOfficeStatus = $selectOfficeQuery->execute();
  if($selectOfficeStatus)
  {
   $rowOffice = $selectOfficeQuery->fetchAll();
      
  }else{
      echo "failed";
    }
  $employeeDetails = "SELECT * FROM exchange_table";
  $employeeDetailsQuery  = $dbh->prepare($employeeDetails);
  $employeeDetailsStatus = $employeeDetailsQuery->execute();
  if($employeeDetailsStatus)
  {
      $rowEmployeeDetails = $employeeDetailsQuery->fetchAll();
      $_SESSION['rowEmployeeDetails'] = $rowEmployeeDetails;
  }else{
      echo "failed";
    }
  if(isset($_POST['totalMailboxSubmit'])){
   $department = $_POST['department'];
   $userSelect = $_POST['userSelect']; 

  if($userSelect == "TOP 30 USERS"  && $department == "NULL") 
      $resultDisplay = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Total Mailbox Size (Mb)`FROM exchange_table WHERE Department = ''  ORDER BY `Total Mailbox Size (Mb)` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS"  && $department == "NULL") 
      $resultDisplay = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Total Mailbox Size (Mb)` FROM exchange_table WHERE Department = ''  ORDER BY `Total Mailbox Size (Mb)` ASC LIMIT 30";
  else if($userSelect == "TOP 30 USERS" && $department == "ALL DEPARTMENTS") 
      $resultDisplay = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Total Mailbox Size (Mb)` FROM exchange_table ORDER BY `Total Mailbox Size (Mb)` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS" && $department == "ALL DEPARTMENTS") 
      $resultDisplay = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Total Mailbox Size (Mb)` FROM exchange_table ORDER BY `Total Mailbox Size (Mb)` ASC LIMIT 30";
  else if($userSelect== "TOP 30 USERS") 
      $resultDisplay = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Total Mailbox Size (Mb)` FROM exchange_table WHERE Department LIKE '$department' ORDER BY `Total Mailbox Size (Mb)` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS") 
      $resultDisplay = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Total Mailbox Size (Mb)` FROM exchange_table WHERE Department LIKE '$department' ORDER BY `Total Mailbox Size (Mb)` ASC LIMIT 30";
  // The below statement will help in knowing which MySQL query got executed.
  //echo $resultDisplay;
    $resultDisplayQuery  = $dbh->prepare($resultDisplay);
    $resultDisplayStatus = $resultDisplayQuery->execute();
    if($resultDisplayStatus)
    {
      echo "good";
      $totalMailboxTableView = $resultDisplayQuery->fetchAll();
      $_SESSION['totalMailboxTableView'] = $totalMailboxTableView;
      echo "<script>window.location='totalMailboxSizeInMbResult.php'</script>";
    }else{
      echo "failed";
    }
  }
    if(isset($_POST['mailboxSubmit'])){
   $department = $_POST['department'];
   $userSelect = $_POST['userSelect'];

  if($userSelect == "TOP 30 USERS" && $department == "NULL") 
      $mailboxResult = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Size (Mb)` FROM exchange_table WHERE Department = ''  ORDER BY `Mailbox Size (Mb)` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS" && $department == "NULL") 
    $mailboxResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Size (Mb)` FROM exchange_table WHERE Department = ''  ORDER BY `Mailbox Size (Mb)` ASC LIMIT 30";
  else if($userSelect == "TOP 30 USERS" && $department == "ALL DEPARTMENTS") 
    $mailboxResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Size (Mb)` FROM exchange_table ORDER BY `Mailbox Size (Mb)` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS" && $department == "ALL DEPARTMENTS") 
    $mailboxResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Size (Mb)` FROM exchange_table ORDER BY `Mailbox Size (Mb)` ASC LIMIT 30";
  else if($userSelect== "TOP 30 USERS") 
    $mailboxResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Size (Mb)` FROM exchange_table WHERE Department LIKE '$department' ORDER BY `Mailbox Size (Mb)` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS") 
    $mailboxResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Size (Mb)` FROM exchange_table WHERE Department LIKE '$department' ORDER BY `Mailbox Size (Mb)` ASC LIMIT 30";
    echo $mailboxResult;
    $mailboxResultQuery  = $dbh->prepare($mailboxResult);
    $mailboxResultStatus = $mailboxResultQuery->execute();
    if($mailboxResultStatus)
    {
      echo "good";
      $mailboxTableView = $mailboxResultQuery->fetchAll();
      $_SESSION['mailboxTableView'] = $mailboxTableView;
      print_r($mailboxTableView);
      echo "<script>window.location='mailboxSizeInMbResult.php'</script>";
      print_r($mailboxTableView);
    }else{
      echo "failed";
    
         }
  }
    if(isset($_POST['mailboxItemsSubmit'])){
   $department = $_POST['department'];
   $userSelect = $_POST['userSelect']; 
    
  if($userSelect == "TOP 30 USERS" && $department == "NULL") 
      $mailboxItemsResult = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Items` FROM exchange_table WHERE Department = ''  ORDER BY `Mailbox Items` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS" && $department == "NULL") 
    $mailboxItemsResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Items` FROM exchange_table WHERE Department = ''  ORDER BY `Mailbox Items` ASC LIMIT 30";
  else if($userSelect == "TOP 30 USERS" && $department == "ALL DEPARTMENTS") 
    $mailboxItemsResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Items` FROM exchange_table ORDER BY `Mailbox Items` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS" && $department == "ALL DEPARTMENTS") 
    $mailboxItemsResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Items` FROM exchange_table ORDER BY `Mailbox Items` ASC LIMIT 30";
  else if($userSelect== "TOP 30 USERS") 
    $mailboxItemsResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Items` FROM exchange_table WHERE Department LIKE '$department' ORDER BY `Mailbox Items` DESC LIMIT 30";
  else if($userSelect == "LEAST 30 USERS") 
    $mailboxItemsResult  = "SELECT DisplayName,`Mailbox Type`,Title,Department,Office,`Mailbox Items` FROM exchange_table WHERE Department LIKE '$department' ORDER BY` Mailbox Items` ASC LIMIT 30";
    echo $mailboxItemsResult;
    $mailboxItemsResultQuery  = $dbh->prepare($mailboxItemsResult);
    $mailboxItemsResultStatus = $mailboxItemsResultQuery->execute();
    if($mailboxItemsResultStatus)
    {
      echo "good";
      $mailboxItemsTableView = $mailboxItemsResultQuery->fetchAll();
      $_SESSION['mailboxItemsTableView'] = $mailboxItemsTableView;
      echo "<script>window.location='mailboxItemsResult.php'</script>";
      print_r($mailboxItemsTableView);
    }else{
      echo "failed";
    }
  }
  if(isset($_POST['memoryUsageSubmit'])){
   $_SESSION['office'] = $_POST['office'];
   $_SESSION['userSelect'] = $_POST['userSelect'];

  if($_SESSION['userSelect'] == "Total Mailbox Size (Mb)"  && $_SESSION['office'] == "NULL") 
      $memoryResult = "SELECT Office, Department, SUM(`Total Mailbox Size (Mb)`) AS '" . $_SESSION['userSelect'] . "' FROM exchange_table WHERE Office = '' GROUP BY Department";
  else if($_SESSION['userSelect'] == "Mailbox Size (Mb)"  && $_SESSION['office'] == "NULL") 
    $memoryResult = "SELECT Office, Department, SUM(`Mailbox Size (Mb)`) AS '" . $_SESSION['userSelect'] . "' FROM exchange_table WHERE Office = '' GROUP BY Department";
  else if($_SESSION['userSelect'] == "Mailbox Items"  && $_SESSION['office'] == "NULL") 
    $memoryResult = "SELECT Office, Department, SUM(`Mailbox Items`) AS '" . $_SESSION['userSelect'] . "' FROM exchange_table WHERE Office = '' GROUP BY Department";
  else if($_SESSION['userSelect'] == "Total Mailbox Size (Mb)") 
   $memoryResult = "SELECT Office, Department, SUM(`Total Mailbox Size (Mb)`) AS '" . $_SESSION['userSelect'] . "' FROM exchange_table WHERE Office LIKE '" . $_SESSION['office'] . "'  GROUP BY Department";
  else if($_SESSION['userSelect'] == "Mailbox Size (Mb)") 
   $memoryResult = "SELECT Office, Department, SUM(`Mailbox Size (Mb)`) AS '" . $_SESSION['userSelect'] . "' FROM exchange_table WHERE Office LIKE '" . $_SESSION['office'] . "'  GROUP BY Department";
  else if($_SESSION['userSelect'] == "Mailbox Items") 
    $memoryResult = "SELECT Office, Department, SUM(`Mailbox Items`) AS '" . $_SESSION['userSelect'] . "' FROM exchange_table WHERE Office LIKE '" . $_SESSION['office'] . "' GROUP BY Department";
    echo $memoryResult;
    $memoryResultQuery  = $dbh->prepare($memoryResult);
    $memoryResultStatus =  $memoryResultQuery ->execute();
    if($memoryResultStatus)
    {
      echo "good";
      $memoryTableView = $memoryResultQuery->fetchAll();
      $_SESSION['memoryTableView'] = $memoryTableView;
      echo "<script>window.location='locationSpecificResult.php'</script>";
      print_r($memoryTableView);
    }else{
      echo "failed";
    }
  }
  if(isset($_POST['loginSubmit'])){
   $department = $_POST['department'];
   $userSelect = $_POST['userSelect']; 
    
  if($userSelect == "IN CURRENT MONTH" && $department == "NULL") 
      $loginResult = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')= MONTH(CURRENT_DATE) AND Department = '' ";
  else if($userSelect == "4 MONTHS AGO" && $department == "NULL") 
    $loginResult  = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')= MONTH(CURRENT_DATE-INTERVAL 4 MONTH) AND Department = '' ";
  else if($userSelect == "TILL TODAY" && $department == "NULL") 
    $loginResult = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')<= (CURRENT_DATE) AND Department = '' ";
  else if($userSelect == "IN CURRENT MONTH" && $department == "ALL DEPARTMENTS") 
    $loginResult  = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')= MONTH(CURRENT_DATE)";
  else if($userSelect == "4 MONTHS AGO" && $department == "ALL DEPARTMENTS") 
    $loginResult  = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')= MONTH(CURRENT_DATE-INTERVAL 4 MONTH)";
  else if ($userSelect == "TILL TODAY" && $department == "ALL DEPARTMENTS")
    $loginResult = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')<= (CURRENT_DATE)";
  else if($userSelect== "IN CURRENT MONTH") 
    $loginResult  = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')= MONTH(CURRENT_DATE) AND Department LIKE '$department'";
  else if($userSelect == "4 MONTHS AGO") 
    $loginResult  = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')= MONTH(CURRENT_DATE-INTERVAL 4 MONTH) AND Department LIKE '$department' ";
  else if($userSelect == "TILL TODAY")
    $loginResult = "SELECT DisplayName, `Mailbox Type`, Title, Department, Office, `Last Mailbox Logon` FROM exchange_table WHERE DATE_FORMAT(STR_TO_DATE(`Last Mailbox Logon`, '%m/%d/%Y'), '%m-%d-%Y')<= (CURRENT_DATE) AND Department LIKE '$department'";
    echo $loginResult;
    $loginResultQuery  = $dbh->prepare($loginResult);
    $loginResultStatus = $loginResultQuery->execute();
    if($loginResultStatus)
    {
      echo "good";
      $loginTableView = $loginResultQuery->fetchAll();
      $_SESSION['loginTableView'] = $loginTableView;
      echo "<script>window.location='loginResult.php'</script>";
      print_r($loginTableView);
    }else{
      echo "failed";
    }
  }
  ?>
