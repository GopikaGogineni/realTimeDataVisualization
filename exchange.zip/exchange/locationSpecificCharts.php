    <!DOCTYPE HTML>
    <html>
    <head>
    <title> Disk Space Usage Graphs</title>    
    <?php
     require("highchartsCommonView.html");
    ?>
    <?php
     //require('commonView.html');
    ?>    
    <script type="text/javascript">
    $(function (){
    <!--Pie chart starts here-->
    $(document).ready(function() {
        var options = {
            chart: {
    renderTo: 'pie',
            type: 'pie',
            options3d: {
                enabled: true,
                alpha: 55,
                beta: 0
                }
            },
            title: {
                text: 'DISK SPACE USAGE BY VARIOUS DEPARTMENTS'
            },
            tooltip: {
                formatter: function() {
                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
                        }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    depth: 35,
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                                    return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
                                }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Browser share',
                data: []
                    }]
    }
    $.getJSON("pieChart_location.php", function(json) {
                    options.series[0].data = json;
                    chart = new Highcharts.Chart(options);
        });
    });
            <!--Pie chart ends here-->
            <!--column chart starts here-->
    $(document).ready(function() {
    var options = {
        chart: {
            renderTo: 'column',
            type: 'column',
            margin: 75,
            options3d: {
                    enabled: true,
                    alpha: 0,
                    beta: 0,
                    depth: 50,
                    viewDistance: 25
                }
    },
                title: {
                    x: -20 //center
                },
                subtitle: {
                    text: '',
                    x: -20
                },
                xAxis: {
                    categories: []
                },
                yAxis: {
                    title: {
                    },
                    plotLines: [{
                        value: 0,
                        width: 1,
                        color: '#808080'
                    }]
                },
    plotOptions: {
                column: {
                    depth: 10
                }
            },
            tooltip: {
                    formatter: function() {
                        return '<b>'+ this.x +'</b><br/>'+
                        this.series.name+': '+ this.y;
                    }
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'top',
                    x: -10,
                    y: 100,
                    borderWidth: 0
                },
                series: []
                }
            var chart1;
            $.getJSON('graphs_location.php', function(json){
             options.chart.renderTo = 'column';
             options.title.text = '';
             options.xAxis.categories = json[0]['data'];
             options.series.push(json[1]);
             chart1 = new Highcharts.Chart(options);
             options.series = [];
                               });

        });
    });<!--This is for the main function-->
    </script>
    </head>
    <body>
    <?php
     require("navbar.html");
    ?>
    <br><br><br>
            <!-- Charts dashboard starts here -->
            <!--First chart-->
                         <div class="col-lg-12">      
                            <div id="pie" style="min-width: 500px; height: 500px; margin: 30 auto"></div>   
                        </div>
                    <!--Second chart-->
                        <div class="col-lg-12">
                            <div id="column" style="min-width: 500px; height: 500px; margin: 30 auto"></div>
                        </div>
    </body>
    </html>
