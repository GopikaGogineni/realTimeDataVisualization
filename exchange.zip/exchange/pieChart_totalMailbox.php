<?php
ob_start();
require("config.php");
ob_end_clean();
$totalMailboxArray = array();
if (isset($_SESSION['totalMailboxTableView'])) {
foreach ((array) $_SESSION['totalMailboxTableView'] as $colName) 
	{
		$colValue[0] = $colName['DisplayName'];
		$colValue[1] = $colName['Total Mailbox Size (Mb)'];
		array_push($totalMailboxArray,$colValue);
	}
}
print json_encode($totalMailboxArray, JSON_NUMERIC_CHECK);
?>
