<?php
ob_start();
require("config.php");
ob_end_clean();
$xaxis = array();
$yaxis = array();
$result = array();
$xaxis['name'] = 'DisplayName';
$yaxis['name'] = 'Total Mailbox Size (Mb)';
if (isset($_SESSION['totalMailboxTableView'])) {
foreach ((array)$_SESSION['totalMailboxTableView'] as $colName) 
	{
	    $xaxis['data'][] = $colName['DisplayName'];
	    $yaxis['data'][] = $colName['Total Mailbox Size (Mb)'];
	}
}
array_push($result,$xaxis);
array_push($result,$yaxis);
print json_encode($result, JSON_NUMERIC_CHECK);
?>
