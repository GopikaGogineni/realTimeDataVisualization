  <?php
  // Start the session
  session_start();
  ?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <title>Login Results</title>
    <?php
      require("commonView.html");
    ?>
  <!-- code for using jQuery Datatables -->  
  <script type="text/javascript" charset="utf-8">
  $(document).ready(function() {
     $(".ColVis_MasterButton").addClass("btn");  
     $('#example').dataTable( { 
        responsive: true, 
        "order": [[ 5, "asc" ]],
        "sScrollY": "410px",
        "sScrollX": "100%", 
        "sScrollXInner": "120%",
        "bScrollCollapse": true,
        "fixedColumns":   {
                leftColumns: 2,
            },
        //set default rows shown to ALL
        "iDisplayLength": -1,
        "aLengthMenu": [[10, 25, -1], [10, 25, "All"]], 
        "pagingType": "full_numbers",
        dom: 'TC<"clear">lfrtip',
        //to display the csv, xls and pdf buttons
             tableTools: {
                      "sSwfPath": "http://cdn.datatables.net/tabletools/2.2.3/swf/copy_csv_xls_pdf.swf",
                      "aButtons": [
                                   "copy",
                                   "print",
                                   {
                                       "sExtends":    "collection",
                                       "sButtonText": "Save",
                                       "aButtons":    [ "csv", "xls", "pdf" ]
                                   }
                       ]        
               }  
                
            
        } );
    } );
  </script>
  </head>
  <body><br><br>
  <?php
    require("navbar.html");
  ?>
  <div>
    <!--<button type="button" onclick="location.href='http://citweb.us.proofpoint.com/totalMailboxCharts.php';" align="left" name ="generategraphs" id="generategraphs" class="btn btn-primary" >GENERATE GRAPHS</button>-->
    <h2>Employee Login Details</h2>
    <table id="example" class="table table-bordered table-striped table-striped-column" cellspacing="0" width="100%">
      <thead>
    <tr>
    <th class="active">DisplayName</th>
    <th class="success">Mailbox Type</th>
    <th class="warning">Title</th>
    <th class="active">Department</th>
    <th class="success">Office</th>
    <th class="warning">Last Mailbox Logon</th>
    </tr>
    </thead>
  <?php
    require("config.php");
    if (is_array($_SESSION['loginTableView']))  
    foreach ($_SESSION['loginTableView'] as $row) {
    echo "<tr>";
    echo "<td class='active' >" . $row['DisplayName'] . "</td>";
    echo "<td class='success'>" . $row['Mailbox Type'] . "</td>";
    echo "<td class='warning'>" . $row['Title'] . "</td>";
    echo "<td class='active'>" . $row['Department'] . "</td>";
    echo "<td class='success'>" . $row['Office'] . "</td>";
    echo "<td class='warning'>" . $row['Last Mailbox Logon'] . "</td>";
    echo "</tr>";
    }

  ?>
  </table>
  </div>
  </body>
  </html>

