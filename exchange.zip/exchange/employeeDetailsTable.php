<?php
// Start the session
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Employee Details</title>
	<?php
	    require('commonView.html');
	    ?>
	    <!-- code for using jQuery datatables -->
	<script type="text/javascript" charset="utf-8">
	$(document).ready(function() {
	 
		$(".ColVis_MasterButton").addClass("btn");  
	    $('#example').dataTable( {
	    responsive: true, 
	    "sScrollY": "410px",
	    "sScrollX": "100%", 
	    "sScrollXInner": "150%",
	    "bScrollCollapse": true,
	    "fixedColumns":   {
	            leftColumns: 2,
	        },
	         //set default rows shown to ALL
		"iDisplayLength": -1,
		"aLengthMenu": [[10, 25, -1], [10, 25, "All"]],	
		"pagingType": "full_numbers",
	    dom: 'TC<"clear">lfrtip',
	//to display the csv, xls and pdf buttons
		tableTools: {
				      "sSwfPath": "http://cdn.datatables.net/tabletools/2.2.3/swf/copy_csv_xls_pdf.swf",
				      "aButtons": [
				                 "copy",
				                 "print",
				                         {
				                           "sExtends":    "collection",
				                           "sButtonText": "Save",
				                           "aButtons":    [ "csv", "xls", "pdf" ]
				                         }
				                  ]        
				         }	
	            } );
	} );
	</script>
	</head>
	 
	<body>
	<?php
	  require("navbar.html");
	 ?>
	<br>
	<h3 class="page-header">Employee Details Table</h3>
	<table id="example" class="table table-bordered table-striped table-striped-column" cellspacing="0" width="100%">
	<?php
$dsn = 'mysql:host=localhost;dbname=exchange';
$username ="root";
$password ="";
$database ="exchange";
  try{
    $dbh = new PDO($dsn, $username, $password);
     }
  catch(PDOException $e){
    echo 'ERROR: ' .$e->getMessage();
    }
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
<thead>
<tr>
<?php  
$columnQuery  = "show columns from exchange_table";
$columnQueryResult  = $dbh->prepare($columnQuery);
$columnQueryResultStatus =  $columnQueryResult ->execute();
if($columnQueryResultStatus)
    {
      $employeeTableView = $columnQueryResult->fetchAll();
         for($i = 0; $i<count($employeeTableView); $i++){
         $fieldname = $employeeTableView[$i]['Field'];
         echo "<th class='success'>$fieldname</th>";
      }
    }
    else{
      echo "failed";
    }
?>
</tr>
</thead>
<tbody>
<?php 
$columnValQuery  = "select * from exchange_table";
$columnValQueryResult  = $dbh->prepare($columnValQuery);
$columnValQueryResultStatus =  $columnValQueryResult ->execute();
if($columnValQueryResultStatus)
    {
      $employeeResTableView = $columnValQueryResult->fetchAll(PDO::FETCH_NUM);
      foreach ($employeeResTableView as $row) {
      foreach ($row as $col) {
      print "\t<td class='warning'>$col</td>\n";
                }
    print "</tr>\n";
     }   
}
  else {
      echo "failed";
    }
 
 ?>
</tbody>
</table>
</body>
</html>

