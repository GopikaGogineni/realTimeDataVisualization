<?php
  // Start the session
  session_start();
?>
<?php
  $dsn = 'mysql:host=localhost;dbname=exchange';
  $username ="root";
  $password ="";
  $database ="exchange";
  try{
    $dbh = new PDO($dsn, $username, $password);
  }
  catch(PDOException $e){
    echo 'ERROR: ' .$e->getMessage();
  }
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $emailResult = "SELECT `Primary Email Address` FROM `exchange_table` WHERE `Mailbox Items` > 1000 ORDER BY `DisplayName`";
    //echo $emailResult;
    $emailResultQuery  = $dbh->prepare($emailResult);
    $emailResultStatus =  $emailResultQuery ->execute();
    if($emailResultStatus)
    {
      //echo "good";
      $email = $emailResultQuery->fetchAll();
      $_SESSION['email'] = $email;
      print_r($email);
      
    }else{
      echo "failed";
    }
?>