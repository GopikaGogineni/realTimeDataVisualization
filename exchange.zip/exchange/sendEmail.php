<?php
  require("emailCollection.php");
  if(is_array($_SESSION['email']))  
  foreach ($_SESSION['email'] as $emailList)
{
$emails = explode("@", $emailList['Primary Email Address']);
$username = $emails[0];
$content = "Hi" . " " . $username . "," . "\r \n \r \n The purpose of this email is to inform you that you currently have 300000 items in you exchange mailbox. Please help clean up and delete any unwanted email.

CIT will be enforcing a policy to limit total items in a mailbox to 200000 or below starting May 15th.  

Thanks for you help in maintaining the health of our mail infrastructure.

Thanks,
CIT";
 
	mail(implode(',', $emailList),'ACTION REQUIRED: Total mail items in exchange mailbox too high',$content ,'From:gopika.gogineni@gmail.com');
}



?>