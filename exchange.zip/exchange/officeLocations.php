<?php
session_start()
?>
<?php
ob_start();
require("config.php");
ob_end_clean();

mysql_connect("localhost","root","gopika");
mysql_select_db("exchange") or die( "Unable to select database");

//if(isset($_SESSION['department'])){
  $selectTag = $_SESSION['department'];
        //$selectTag1 = $_POST['nav']; 
// To know what user has selected from the dropdown
//echo "select is: "."" .$selectTag;
//}
$sql = "SELECT DISTINCT Office from sample WHERE Department LIKE '$selectTag' ORDER BY Office ASC";
$rs = mysql_query($sql) or die($sql. "<br/>".mysql_error());
$rows = array();
while($r = mysql_fetch_array($rs)) {
    $row[0] = $r[0];
    //$row[1] = $r[1];
    array_push($rows,$row);
}
print json_encode($rows, JSON_NUMERIC_CHECK);
?>
