  <?php
  $dsn = 'mysql:host=localhost;dbname=exchange';
    $username ="root";
    $password ="";
    $database ="exchange";
    try{
      $dbh = new PDO($dsn, $username, $password);
    }
    catch(PDOException $e){
      echo 'ERROR: ' .$e->getMessage();
    }
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //Creating a table named dummy_similar which has the same structure like similar.
    $dummyTable = "CREATE table dummy_similar LIKE similar";
    $dummyTableQuery  = $dbh->prepare($dummyTable);
    $dummyTableStatus = $dummyTableQuery->execute();
    //Loading the data into the created dummysimilar table
    $loadDummyTable = "LOAD DATA INFILE 'C://exchangeData.csv' INTO TABLE dummy_similar FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES";
    $loadDummyTableQuery  = $dbh->prepare($loadDummyTable);
    $loadDummyTableStatus = $loadDummyTableQuery->execute();
    //Emptying the original table. Here it is similar
    $truncateOriginalTable = "TRUNCATE table similar";
    $truncateOriginalTableQuery  = $dbh->prepare($truncateOriginalTable); 
    $truncateOriginalTableStatus = $truncateOriginalTableQuery->execute();
    //Filling the similar table with the modified values
    $updateOriginalTable = "REPLACE into similar select * from dummy_similar";
    $updateOriginalTableQuery  = $dbh->prepare($updateOriginalTable);
    $updateOriginalTableStatus = $updateOriginalTableQuery->execute();
    //Finally, dropping the duplicate table
    $deleteDummyTable = "DROP table dummy_similar";
    $deleteDummyTableQuery  = $dbh->prepare($deleteDummyTable);
    $deleteDummyTableStatus = $deleteDummyTableQuery->execute();
    echo "The data has been loaded successfully!!";
  ?>

