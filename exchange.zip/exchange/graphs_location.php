<?php
ob_start();
require("config.php");
ob_end_clean();
$xaxis = array();
$yaxis = array();
$result = array();
$xaxis['name'] = 'Department';
if (isset($_SESSION['userSelect']))
$yaxis['name'] = $_SESSION['userSelect'];
if (isset($_SESSION['memoryTableView'])) {
foreach ((array)$_SESSION['memoryTableView'] as $colName) 
	{
		$xaxis['data'][] = $colName['Department'];
		$yaxis['data'][] = $colName[$_SESSION['userSelect']];
		      
	}
}
array_push($result,$xaxis);
array_push($result,$yaxis);
print json_encode($result, JSON_NUMERIC_CHECK);
?>
