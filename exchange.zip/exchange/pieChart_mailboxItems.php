<?php
ob_start();
require("config.php");
ob_end_clean();
$mailboxItemsArray = array();
if (isset($_SESSION['mailboxItemsTableView'])) {
foreach ((array) $_SESSION['mailboxItemsTableView'] as $colName)
	{
		$colValue[0] = $colName['DisplayName'];
		$colValue[1] = $colName['Mailbox Items'];
		array_push($mailboxItemsArray,$colValue);
	}
}
print json_encode($mailboxItemsArray, JSON_NUMERIC_CHECK);
?>
