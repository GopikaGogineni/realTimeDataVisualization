<?php
ob_start();
require("config.php");
ob_end_clean();
$mailboxArray = array();
if (isset($_SESSION['mailboxTableView'])) {
foreach ((array) $_SESSION['mailboxTableView'] as $colName) 
		{
		$colValue[0] = $colName['DisplayName'];
		$colValue[1] = $colName['Mailbox Size (Mb)'];
		array_push($mailboxArray,$colValue);
		}
}
print json_encode($mailboxArray, JSON_NUMERIC_CHECK);
?>
