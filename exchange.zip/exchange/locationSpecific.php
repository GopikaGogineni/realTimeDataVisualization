  <?php
  // Start the session
  session_start();
  // Below print statement is used to check the variables present in the SESSION variable
  //print_r($_SESSION);
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <title>Disk Space Usage In Various Locations</title>
  <?php
    require("commonView.html");
  ?>
  </head>
  <body>
  <?php
    require("navbar.html");
  ?>
  <br> <br>
  <h2 align="center">Disk space usage by various office locations</h2><br><br><br><br>
  <div class="container">
     <form class="form-inline" role="form" action ="config.php"  method = "POST" >
              <div class="form-group" align="center">
              <label for="display">DISPLAY</label>
              <select class="selectpicker" name="userSelect" data-live-search="true" data-style="btn-warning">
              <option>Total Mailbox Size (Mb)</option>
              <option>Mailbox Size (Mb)</option>
              <option>Mailbox Items</option>
              </select>
              </div> <!-- closing form-group -->
        <div class="form-group">
        <label for="of departments in">OF DEPARTMENTS IN</label>
        <?php
         require("config.php");
         echo '<select class="selectpicker" name="office" data-live-search="true" data-style="btn-warning">';
         foreach($rowOffice as $row) {
         echo "<option value='" . $row['Office'] ."'>" . $row['Office'] ."</option>";
          }
         echo "<option>NULL</option>";
         echo "</select>";
         ?>
       </div> <!-- closing the second form-goup in the form -->
  <button class="btn btn-success" type="submit" name ="memoryUsageSubmit">Submit</button>
</form>
</div> <!-- closing container class -->
</body>
</html>
