<?php
ob_start();
require("config.php");
ob_end_clean();
$memoryUsageArray = array();
if (isset($_SESSION['memoryTableView'])) {
foreach ($_SESSION['memoryTableView'] as $colName) 
	 {
	 $colValue[0] = $colName['Department'];
	 $colValue[1] = $colName[$_SESSION['userSelect']];
	array_push($memoryUsageArray,$colValue);
	}
}
print json_encode($memoryUsageArray, JSON_NUMERIC_CHECK);
?>
